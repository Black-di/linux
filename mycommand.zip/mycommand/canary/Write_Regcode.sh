#/bin/bash
Unused_file_path = "`pwd`/Unused.csv"
Used_file_path = "`pwd`/Used.csv"
echo "Clearing VPD_RW..."
VPD -i RW_VPD -O
echo "Reading regcode file.."
if [ ! -f "$Unused_file_path" ];then
	echo "${Unused_file_path} don't exist!"
	exit 1
if [ ! -f "$Used_file_path" ];then
	echo "${Used_file_path} don't exist!"
	exit 1
user_code = `sed -n '1p' ${Unused_file_path} | awk -F ',' '{printf $1}'`
group_code = `sed -n '1p' ${Unused_file_path} | awk -F ',' '{printf $2}'`
echo "Writing new code to device"
vpd -i RW_VPD -s "gbind_attribute=${user_code}"
vpd -i RW_VPD -s "ubind_attribute=${group_code}"
echo "Checking result...."
vpd -i RW_VPD -l
flag = "F"
while [ $flag != "y" && $flag != "Y" ]
do
	if [ $flag = "N" || $flag = "n" ];then
		exit 1
	read -p "Please ensure regcode write correctly(y/n)" flag
done
echo "Backup used code to Used.csv"
sed -i "1 a${user_code},${group_code}" $Used_file_path 
echo "Deleting old code in Unused.csv"
sed '1d' $Unused_file_path
echo "Done!!!"
