# Copyright 2014 The Chromium OS Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

from __future__ import print_function

import asyncore
import logging
import factory_common  # pylint: disable=unused-import
from cros.factory.external import evdev
from cros.factory.utils import process_utils


def GetDevices():
  """Gets all the input devices.

  Returns:
    A list of evdev.InputDevice() instances of the input devices.
  """
  return [evdev.InputDevice(d) for d in evdev.list_devices()]


def IsLidEventDevice(dev):
  """Check if a device is with EV_SW and SW_LID capabilities.

  Args:
    dev: evdev.InputDevice

  Returns:
    True if dev is a lid event device.
  """
  return evdev.ecodes.SW_LID in dev.capabilities().get(evdev.ecodes.EV_SW, [])

def IsTabletEventDevice(dev):
  """Check if a device is with EV_SW and SW_TABLET_MODE capabilities.

  Args:
    dev: evdev.InputDevice

  Returns:
    True if dev is a tablet event device.
  """
  return evdev.ecodes.SW_TABLET_MODE in dev.capabilities().get(
      evdev.ecodes.EV_SW, [])



def IsKeyboardDevice(dev):
  """Check if a device is with EV_KEY and KEY_ENTER capabilities.

  Args:
    dev: evdev.InputDevice

  Returns:
    True if dev is a keyboard device.
  """
  return evdev.ecodes.KEY_ENTER in dev.capabilities().get(evdev.ecodes.EV_KEY,
                                                          [])


def SendKeys(key_sequence):
  """Sends the given key sequence through uinput.

  Args:
    key_sequence: A list of keys to send.  For the list of valid key events, see
        evdev.ecodes module.
  """
  uinput = evdev.UInput()
  for k in key_sequence:
    uinput.write(evdev.ecodes.EV_KEY, k, 1)
  for k in key_sequence:
    uinput.write(evdev.ecodes.EV_KEY, k, 0)
  uinput.syn()
  uinput.close()


def IsTouchDevice(dev):
  """Check if a device is a touch device.

  Args:
    dev: evdev.InputDevice

  Returns:
    True if dev is a touch device.
  """
  keycaps = dev.capabilities().get(evdev.ecodes.EV_KEY, [])
  return evdev.ecodes.BTN_TOUCH in keycaps


def IsStylusDevice(dev):
  """Check if a device is a stylus device.

  Args:
    dev: evdev.InputDevice

  Returns:
    True if dev is a stylus device.
  """
  keycaps = dev.capabilities().get(evdev.ecodes.EV_KEY, [])
  logging.info('keycaps========%s',keycaps)
  logging.info('evdev.ecodes.BTN_STYLUS,BTN_STYLUS2,BTN_TOOL_PEN============%s',[evdev.ecodes.BTN_STYLUS,evdev.ecodes.BTN_STYLUS2,evdev.ecodes.BTN_TOOL_PEN])
  return bool(set(keycaps) & set([
      evdev.ecodes.BTN_STYLUS,
      evdev.ecodes.BTN_STYLUS2,
      evdev.ecodes.BTN_TOOL_PEN]))


def IsTouchpadDevice(dev):
  """Check if a device is a touchpad device.

  Args:
    dev: evdev.InputDevice

  Returns:
    True if dev is a touchpad device.
  """
  keycaps = dev.capabilities().get(evdev.ecodes.EV_KEY, [])
  return (evdev.ecodes.BTN_TOUCH in keycaps and
          evdev.ecodes.BTN_MOUSE in keycaps)


def IsTouchscreenDevice(dev):
  """Check if a device is a touchscreen device.

  Args:
    dev: evdev.InputDevice

  Returns:
    True if dev is a touchscreen device.
  """
  logging.info('evdev.ecodes.ABS_MT_SLOT==========%s',evdev.ecodes.ABS_MT_SLOT)
  logging.info('evdev.ecodes.EV_ABS==========%s',dev.capabilities().get(evdev.ecodes.EV_KEY, []))
  return (not IsTouchpadDevice(dev) and
          evdev.ecodes.ABS_MT_SLOT in dict(
              dev.capabilities().get(evdev.ecodes.EV_ABS, [])))


class DeviceNotFoundError(RuntimeError):
  pass


class MultipleDevicesFoundError(RuntimeError):
  pass


def FindDevice(*args):
  """Find a device that match all arguments.

  Args:
    Each argument should be None (skipped), int (event id), str (pattern to
    search in evdev name), or a filter function with domain evdev.InputDevice.

  Returns:
    An evdev.InputDevice
  """
  candidates = GetDevices()

  for item in args:
    # pylint: disable=cell-var-from-loop
    if item is None:
      continue
    if isinstance(item, int):
      dev_filter = lambda dev: dev.fn == '/dev/input/event%d' % item
    elif isinstance(item, str):
      dev_filter = lambda dev: item in dev.name
    elif callable(item):
      dev_filter = item
    else:
      raise ValueError('Invalid argument %r' % item)
    candidates = filter(dev_filter, candidates)
  logging.info('candidates==========%s',candidates[0])
  if len(candidates) == 1:
    return candidates[0]
  elif not candidates:
    raise DeviceNotFoundError("Can't find device.")
  else:
    raise MultipleDevicesFoundError('Not having exactly one candidate!')


def DeviceReopen(dev):
  """Reopen a device so that the event buffer is cleared.

  Args:
    dev: evdev.InputDevice

  Returns:
    A different evdev.InputDevice of the same device but with empty event
    buffer.
  """
  return evdev.InputDevice(dev.fn)


class InputDeviceDispatcher(asyncore.file_dispatcher):
  """Extends asyncore.file_dispatcher to read input device."""

  def __init__(self, device, event_handler):
    self.device = device
    self.event_handler = event_handler
    asyncore.file_dispatcher.__init__(self, device)

  def recv(self, ign=None):
    del ign  # Unused.
    return self.device.read()

  def handle_read(self):
    for event in self.recv():
      self.event_handler(event)

  def writable(self):
    return False

  def StartDaemon(self):
    """Start a daemon thread forwarding events to event_handler."""
    process_utils.StartDaemonThread(target=asyncore.loop)
